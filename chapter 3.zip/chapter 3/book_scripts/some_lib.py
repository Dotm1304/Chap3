x = 5
y = [1, 2, 3, 4]
get_answer = get_answer(x, y)


