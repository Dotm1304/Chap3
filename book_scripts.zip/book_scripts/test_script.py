import some_lib
result = some_lib.get_answer(x, y)